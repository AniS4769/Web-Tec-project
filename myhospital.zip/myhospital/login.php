<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login From</title>

    <link rel="stylesheet" type="text/css" href="index.css">

    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

</head>
<body background="pic.jpg">


<center>

<div>
    <form action="login_check.php" method="POST" class="us">

    <center class="titel">

    Login From


      </center>

      <center>

      <div class="from_deg">

        <label class="label_deg">Username</label>
        <input type="text"  name="username">

      </div>

      <div>

        <label class="label_deg">Password</label>
        <input type="password"  name="password">

      </div>

      <div>
        
        <input class="btn btn-primary" type="submit"  name="Login" value="login">
      </div>


    </form>
</div>

</center>
    
</body>
</html>